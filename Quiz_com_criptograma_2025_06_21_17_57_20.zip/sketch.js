let perguntas = [
    { pergunta:'Quais são os 3 produtos que a agricultura do Brasil mais produzem?',
  resposta:'soja, laranja e carne-bovina'},
  
  { pergunta:'Quais são os 2 tipos de agricultura no Brasil?',
   resposta:'agricultura familiar e agricultura comercial'},
  
  { pergunta:'Qual o setor da agricultura predominante no Brasil?',
    resposta:'agricultura familiar'},
  
  { pergunta:'No que a cidade mais ajuda o campo?',
    resposta:'tecnologia'},
  
  { pergunta:'3 produtos que a cidade fornece para o campo?',
    resposta:'maquinas agrícolas, produtos de higiene e beleza, alimentos procesasdos'},
  
  { pergunta:'Qual o tipo de interação entre a cidade e o campo?',
    resposta:'dependencia mútua'}
];

let indice = 0;
let input, botao;
let mensagem = '';
let deslocamento = 3;

function setup() {
  createCanvas(600, 400);
  textSize(16);
  
  input = createInput();
  input.position(30, 330);
  input.size(300);
  
  botao = createButton('Responder');
  botao.position(input.x + input.width + 10, input.y);
  botao.mousePressed(verificarResposta);
  }

function draw() {
  background('rgb(184,241,184)');
  if(indice < perguntas.length) {
    let atual = perguntas[indice];
    fill(0);
    text('Pergunta:', 20, 50);
    text(atual.pergunta, 20, 80, 560, 200);
    text('Dica: digite a resposta criptografada (Cifra de César +3)', 20, 300);
    } else {
      fill('black');
      text('Fim do quiz! 🎉', 209, 210);
      input.hide();
      botao.hide();
    }
      
    fill(0);
    text(mensagem, 20, 150, 560, 100);
}

function cifraCesar(texto, deslocamento) {
  let resultado = '';
  texto = texto.toUpperCase();
  
  for (let i = 0; i < texto.length; i ++) {
    let c = texto.charCodeAt(i);
    if(c >= 65 && c <= 90) {
      let novaLetra = ((c - 65 + deslocamento)% 26) + 65;
  resultado += String.fromCharCode(novaLetra);
   } else{ 
   resultado += texto[i];
   }
  }
  return resultado;
}

function verificarResposta() {
  let respostaDigitada = input.value().trim().toUpperCase();
  let respostaOriginal = perguntas[indice].resposta.toUpperCase();
  let respostaCriptografada = cifraCesar(respostaOriginal, deslocamento);
  
  if(respostaDigitada === respostaCriptografada){
    mensagem = '✅ correto!';
  } else{
    mensagem = '❌  errada!\n' + 'Resosta correta:' +  respostaOriginal + '\n' + 'Criptografada (César + 3):'+ respostaCriptografada;
  }
  
  setTimeout (() => {
    indice++;
    input.value('');
    mensagem = '';
  }, 4000);
}